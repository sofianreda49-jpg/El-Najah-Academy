from sqlalchemy.orm import Session

from app.models.audit import AuditLog

LOGIN = "login"
LOGIN_FAILED = "login_failed"
ACCOUNT_LOCKED = "account_locked"
PASSWORD_CHANGED = "password_changed"
PASSWORD_RESET = "password_reset"
USER_CREATED = "user_created"
USER_UPDATED = "user_updated"
USER_ACTIVATED = "user_activated"
USER_DEACTIVATED = "user_deactivated"


def log_action(
    db: Session,
    *,
    actor_id: int | None,
    action: str,
    target_type: str | None = None,
    target_id: int | None = None,
    detail: str | None = None,
    ip: str | None = None,
) -> None:
    """يضيف سطر للسجل. الـ commit مسؤولية اللي بينادي (علشان يتحفظ مع العملية نفسها)."""
    db.add(
        AuditLog(
            actor_id=actor_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            detail=detail,
            ip_address=ip,
        )
    )
